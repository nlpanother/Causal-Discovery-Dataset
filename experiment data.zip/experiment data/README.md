**Submission Dataset Release**

- Experiment dataset for the submission [High-dimensional Rumor Text Causal Discovery Based on Graph Selection Attention Mechanism]

- DXYdata.csv is the DXY-Data dataset used in the experiment section.
- DREAM4 is the DREAM4 dataset used in the experiment section.
- Rumor.tsv is the Rumor-Data dataset used in the experiment section.